from structpy.automaton.dfa import DFA
from structpy.automaton.state_machine import StateMachine
