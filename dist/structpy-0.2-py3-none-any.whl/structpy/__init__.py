
"""
#Standard

## graph

code for graph representations

## model

something about modelling
"""

from structpy.language.pointer import Pointer, PointerItem
from structpy.language.interface import I, interface