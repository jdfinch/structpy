
from structpy.model.model_graph import ModelGraph