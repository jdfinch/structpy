
from structpy.language.primitive.floating_point import Float
from structpy.language.primitive.integer import Integer
